## Grupo N° 5 - Actividad N° 2
Integrantes:
- Albornoz Ramos, Joel Wilson
- Amaya Cobeñas, Jorge
- Tasayco Magallanes, Angeles Anthoanette
- Gamboa Guerra, Yuori